# prosemirror-model

[ [**WEBSITE**](https://prosemirror.net) | [**ISSUES**](https://code.haverbeke.berlin/prosemirror/prosemirror/issues) | [**FORUM**](https://discuss.prosemirror.net) | [**CHANGELOG**](https://code.haverbeke.berlin/prosemirror/prosemirror-model/src/branch/main/CHANGELOG.md) ]

This is a [core module](https://prosemirror.net/docs/ref/#model) of [ProseMirror](https://prosemirror.net).
ProseMirror is a well-behaved rich semantic content editor based on
contentEditable, with support for collaborative editing and custom
document schemas.

This [module](https://prosemirror.net/docs/ref/#model) implements
ProseMirror's [document model](https://prosemirror.net/docs/guide/#doc),
along with the mechanisms needed to support
[schemas](https://prosemirror.net/docs/guide/#schema).

The [project page](https://prosemirror.net) has more information, a
number of [examples](https://prosemirror.net/examples/) and the
[documentation](https://prosemirror.net/docs/).

This code is released under an
[MIT license](https://code.haverbeke.berlin/prosemirror/prosemirror/src/branch/main/LICENSE).
There's a [forum](http://discuss.prosemirror.net) for general
discussion and support requests, and the
[bug tracker](https://code.haverbeke.berlin/prosemirror/prosemirror/issues)
is the place to report issues.

We aim to be an inclusive, welcoming community. To make that explicit,
we have a [code of
conduct](http://contributor-covenant.org/version/1/1/0/) that applies
to communication around the project.
