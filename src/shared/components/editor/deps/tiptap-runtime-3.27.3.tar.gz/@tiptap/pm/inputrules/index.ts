export * from 'prosemirror-inputrules'
